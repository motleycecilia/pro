const termUnit = {
  "Y": "年",
  "M": "月",
  "D": "日"
}
export default termUnit
