const policy  = {
  result: []
}

// const policy = {
//   responseCode:"000000",
//   responseData: {
//     createTime:"2016-09-09 17:43:58.483211",
//     id:1,
//     insurerBirthday:"1976-08-18",
//     insurerClientNo:"729811450780230322",
//     insurerEmail:"123@a.com",
//     insurerIdNo:"522635197608189322",
//     insurerMobile:"13351222012",
//     insurerName:"威风",
//     insurerSex:"F",
//     isBindCard:"1",
//     updateTime:"2016-09-09 17:43:58.483211"
//   }
// }

export default policy
