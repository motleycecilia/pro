const pre = {
id: 1486561142273,
  memo: "操作成功",
  operationType: "premiumCalculate",
  result: {
    payPremList: [{
      orderStatus: "2003",
      payPrem: "84.00",
      preOrderNo: "2017020800030567",
      productId: "10028680",
      productName: "境外旅行保险（全球）"
    },{
      orderStatus: "2003",
      payPrem: ".00",
      preOrderNo: "2017020800030567",
      productId: "10028680",
      productName: "境外旅行保险（全球）"
    }],
    serialNo: "298190d5-0611-4c6c-89e8-27ef4790c002",
    totalPayPrem: 84
  },
  resultStatus: 1000
}
export default pre
