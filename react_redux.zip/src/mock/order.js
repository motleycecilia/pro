const order ={
    "requestData": {
        "userId": "277121462956038738",
        "from": "wap-chaosh",
        "source": "yzt",
        "activity": "chaoshi",
        "userChannel": "0",
        "subOrderNo": "20160819006288191",
        "insuranceProductInfo": {
            "productId": 63146
        }
    }
}
