const beInsure = {
  responseCode: '000000',
  responseData:[
    // {
    //   id:"0",
    //   insurantName: '姓名',
    //   insurantIdType: '2',
    //   insurantIdNo: '47283920019983920',
    //   insurantMobile: '13009382736',
    //   insurantRelation: '3',
    //   insurantBirthday: '1992-02-02',
    //   insurantSex: 'F'
    // },
    // {
    //   id:"2",
    //   insurantName: '姓名',
    //   insurantIdType: '1',
    //   insurantIdNo: '47283920019983920',
    //   insurantMobile: '13009382737',
    //   insurantRelation: '2',
    //   insurantBirthday: '1992-02-02',
    //   insurantSex: 'F'
    // }
    {
     "id": 81,
     "insurantName": "元翔宇",
     "insurantIdType": "1",
     "createTime": "2016-09-12 16:17:06.516272",
     "insurantSex": "M",
     "updateTime": "2016-09-20 14:22:53.133607",
     "insurantBirthday": "1967-10-13",
     "insurantRelation": "1",
    "insurantMobile": "15560624004",
     "insurerClientNo": "523481466749218728",
     "insurantIdNo": "341523196710134790"
   },
   {
     "id": 401,
     "insurantName": "范文芳",
     "insurantIdType": "5",
     "createTime": "2016-09-13 17:26:05.636195",
     "insurantSex": "F",
     "updateTime": "2016-09-13 19:43:22.194651",
     "insurantBirthday": "2007-02-07",
     "insurantRelation": "3",
     "insurantMobile": "13912038012",
     "insurerClientNo": "643751473758681299",
     "insurantIdNo": "1123"
   }
  ],
  responseMessage: '处理成功'
}

export default beInsure
