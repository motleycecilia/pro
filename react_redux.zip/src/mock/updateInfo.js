const updateInfo = {
  "responseMessage": "处理成功",
  "responseCode": "000000"
}
